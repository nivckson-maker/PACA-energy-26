import React from 'react';
import { Mail, Phone } from 'lucide-react';
import { Inquiry } from '../../types.ts';

interface AdminInquiriesProps {
  inquiries: Inquiry[];
}

export const AdminInquiries: React.FC<AdminInquiriesProps> = ({ inquiries }) => (
  <div className="bg-white rounded-lg shadow-sm border border-gray-200">
    <div className="p-6 border-b border-gray-200">
      <h3 className="text-lg font-bold">Recent Inquiries</h3>
    </div>
    <div className="divide-y divide-gray-100">
      {inquiries.length === 0 ? (
        <div className="p-8 text-center text-gray-500">No inquiries yet.</div>
      ) : (
        inquiries.map((inq, idx) => (
          <div key={inq.id || idx} className="p-6 hover:bg-gray-50 transition-colors">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h4 className="font-bold text-gray-900">{inq.name}</h4>
                <div className="text-sm text-gray-500 flex items-center gap-2">
                  <Mail size={12} /> {inq.email} • <Phone size={12} /> {inq.phone}
                </div>
              </div>
              <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600">{inq.type}</span>
            </div>
            <p className="text-gray-700 mt-2 text-sm bg-blue-50/50 p-3 rounded">{inq.message}</p>
          </div>
        ))
      )}
    </div>
  </div>
);
