import React from 'react';
import { LayoutDashboard, FolderPlus, Hammer, MessageSquare } from 'lucide-react';
import { AdminStats } from '../../types.ts';

interface AdminDashboardProps {
  stats: AdminStats;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ stats }) => (
  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gray-500 text-sm font-medium">Total Projects</h3>
        <FolderPlus className="text-blue-500" size={20} />
      </div>
      <p className="text-3xl font-bold">{stats.projects}</p>
    </div>
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gray-500 text-sm font-medium">Services Active</h3>
        <Hammer className="text-orange-500" size={20} />
      </div>
      <p className="text-3xl font-bold">{stats.services}</p>
    </div>
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gray-500 text-sm font-medium">New Inquiries</h3>
        <MessageSquare className="text-green-500" size={20} />
      </div>
      <p className="text-3xl font-bold">{stats.inquiries}</p>
    </div>
  </div>
);
