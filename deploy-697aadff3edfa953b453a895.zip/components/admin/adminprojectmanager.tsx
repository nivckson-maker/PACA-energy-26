import React, { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '../ui/Button.tsx';
import { Project } from '../../types.ts';

interface AdminProjectManagerProps {
  projects: Project[];
  onAdd: (project: Omit<Project, 'id'>) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}

export const AdminProjectManager: React.FC<AdminProjectManagerProps> = ({ projects, onAdd, onDelete }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newProject, setNewProject] = useState<Omit<Project, 'id'>>({ title: '', client: '', year: '', category: 'Construction', description: '', location: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(newProject);
    setIsAdding(false);
    setNewProject({ title: '', client: '', year: '', category: 'Construction', description: '', location: '' });
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200 flex justify-between items-center">
        <h3 className="text-lg font-bold">Manage Projects</h3>
        <Button variant="primary" onClick={() => setIsAdding(!isAdding)} className="!py-2 !px-4 text-sm">
          <Plus size={16} /> Add New
        </Button>
      </div>
      
      {isAdding && (
        <div className="p-6 bg-blue-50 border-b border-blue-100">
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input placeholder="Project Title" required className="p-2 border rounded" value={newProject.title} onChange={e=>setNewProject({...newProject, title: e.target.value})} />
            <input placeholder="Client Name" required className="p-2 border rounded" value={newProject.client} onChange={e=>setNewProject({...newProject, client: e.target.value})} />
            <input placeholder="Location" required className="p-2 border rounded" value={newProject.location} onChange={e=>setNewProject({...newProject, location: e.target.value})} />
            <div className="grid grid-cols-2 gap-2">
               <input placeholder="Year" required className="p-2 border rounded" value={newProject.year} onChange={e=>setNewProject({...newProject, year: e.target.value})} />
               <select className="p-2 border rounded" value={newProject.category} onChange={e=>setNewProject({...newProject, category: e.target.value})}>
                 <option>Construction</option>
                 <option>Maintenance</option>
                 <option>Procurement</option>
                 <option>Instrumentation</option>
               </select>
            </div>
            <textarea placeholder="Description" className="md:col-span-2 p-2 border rounded" value={newProject.description} onChange={e=>setNewProject({...newProject, description: e.target.value})} />
            <div className="md:col-span-2 flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setIsAdding(false)}>Cancel</Button>
              <Button variant="primary" type="submit">Save Project</Button>
            </div>
          </form>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-gray-50 text-gray-500 text-xs uppercase">
             <tr>
               <th className="p-4">Project</th>
               <th className="p-4">Client</th>
               <th className="p-4">Year</th>
               <th className="p-4">Category</th>
               <th className="p-4 text-right">Actions</th>
             </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {projects.map(project => (
              <tr key={project.id}>
                <td className="p-4 font-medium">{project.title}</td>
                <td className="p-4 text-gray-600">{project.client}</td>
                <td className="p-4 text-gray-600">{project.year}</td>
                <td className="p-4"><span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">{project.category}</span></td>
                <td className="p-4 text-right">
                  <button onClick={() => onDelete(project.id)} className="text-red-500 hover:bg-red-50 p-2 rounded"><Trash2 size={16} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
