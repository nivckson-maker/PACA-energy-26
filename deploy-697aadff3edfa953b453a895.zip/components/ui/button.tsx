import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  className?: string;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  className = '', 
  onClick, 
  type = 'button', 
  disabled = false 
}) => {
  const baseStyle = "px-6 py-3 rounded font-semibold transition-all duration-200 flex items-center justify-center gap-2";
  const variants = {
    primary: "bg-blue-900 text-white hover:bg-blue-800 shadow-lg",
    secondary: "bg-orange-500 text-white hover:bg-orange-600 shadow-md",
    outline: "border-2 border-blue-900 text-blue-900 hover:bg-blue-50",
    ghost: "text-gray-600 hover:text-blue-900 hover:bg-gray-100",
    danger: "bg-red-600 text-white hover:bg-red-700"
  };
  return (
    <button 
      type={type} 
      className={`${baseStyle} ${variants[variant]} ${className} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
};
