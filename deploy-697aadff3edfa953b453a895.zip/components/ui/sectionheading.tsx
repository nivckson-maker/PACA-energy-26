import React from 'react';

interface SectionHeadingProps {
  subtitle: string;
  title: string;
  align?: 'center' | 'left';
  light?: boolean;
}

export const SectionHeading: React.FC<SectionHeadingProps> = ({ 
  subtitle, 
  title, 
  align = 'center', 
  light = false 
}) => (
  <div className={`mb-12 ${align === 'center' ? 'text-center' : 'text-left'}`}>
    <span className={`uppercase tracking-wider text-sm font-bold ${light ? 'text-orange-400' : 'text-orange-600'}`}>
      {subtitle}
    </span>
    <h2 className={`text-3xl md:text-4xl font-bold mt-2 ${light ? 'text-white' : 'text-gray-900'}`}>
      {title}
    </h2>
    <div className={`h-1 w-20 bg-orange-500 mt-4 ${align === 'center' ? 'mx-auto' : ''}`}></div>
  </div>
);
