import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    viewBox="0 0 300 80" 
    className={className}
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    {/* Flame Icon Group */}
    <g transform="translate(0, 5)">
      {/* Outer Flame - Orange */}
      <path 
        d="M25 0C15 0 5 15 5 30C5 45 15 55 25 55C35 55 45 45 45 30C45 15 35 0 25 0Z" 
        fill="url(#flameGradient)"
      />
      <path 
        d="M25 2C38 2 43 15 43 30C43 43 36 53 25 53C14 53 7 43 7 30C7 15 12 2 25 2Z" 
        fill="#ea580c"
      />
      
      {/* Inner Drop - Blue */}
      <circle cx="25" cy="35" r="10" fill="#1e3a8a" stroke="white" strokeWidth="1" />
      
      {/* Letter P - Green */}
      <text 
        x="25" 
        y="40" 
        textAnchor="middle" 
        fill="#22c55e" 
        fontSize="14" 
        fontWeight="bold" 
        fontFamily="Arial, sans-serif"
      >
        P
      </text>
    </g>

    {/* Text Group */}
    <g transform="translate(55, 10)">
      <text 
        x="0" 
        y="25" 
        fill="#ea580c" 
        fontSize="28" 
        fontWeight="800" 
        fontFamily="Arial, sans-serif"
        style={{ filter: 'drop-shadow(1px 1px 0px rgba(0,0,0,0.1))' }}
      >
        PACA ENERGY
      </text>
      
      <text 
        x="0" 
        y="50" 
        fill="#1f2937" 
        fontSize="14" 
        fontWeight="bold" 
        letterSpacing="0.35em"
        fontFamily="Arial, sans-serif"
      >
        SERVICES <tspan fontSize="10" dy="-4">LTD</tspan>
      </text>
      
      {/* Red Line */}
      <line x1="0" y1="58" x2="200" y2="58" stroke="#dc2626" strokeWidth="2" />
    </g>

    {/* Definitions */}
    <defs>
      <linearGradient id="flameGradient" x1="25" y1="0" x2="25" y2="55" gradientUnits="userSpaceOnUse">
        <stop stopColor="#f97316"/>
        <stop offset="1" stopColor="#ea580c"/>
      </linearGradient>
    </defs>
  </svg>
);
