import React, { useState } from 'react';
import { MapPin, Mail, Phone } from 'lucide-react';
import { Button } from '../ui/Button.tsx';
import { SectionHeading } from '../ui/SectionHeading.tsx';
import { Inquiry } from '../../types.ts';
import { ADDRESS } from '../../constants.ts';

interface ContactSectionProps {
  onInquirySubmit: (data: Inquiry) => Promise<void>;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onInquirySubmit }) => {
  const [form, setForm] = useState<Inquiry>({ name: '', email: '', phone: '', message: '', type: 'General Inquiry', company: '' });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    try {
      await onInquirySubmit(form);
      setStatus('success');
      setForm({ name: '', email: '', phone: '', message: '', type: 'General Inquiry', company: '' });
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  return (
    <section className="py-20 bg-white" id="contact">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <SectionHeading subtitle="Get In Touch" title="Partner With Us" align="left" />
            <p className="text-gray-600 mb-8">
              Whether you need a quote for fabrication, maintenance support, or project management consultancy, our team is ready to assist.
            </p>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-blue-100 p-3 rounded-full text-blue-900"><MapPin size={20} /></div>
                <div>
                  <h4 className="font-bold text-gray-900">Head Office</h4>
                  <p className="text-gray-600 max-w-sm">{ADDRESS}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-blue-100 p-3 rounded-full text-blue-900"><Mail size={20} /></div>
                <div>
                  <h4 className="font-bold text-gray-900">Email Us</h4>
                  <p className="text-gray-600">info@pacaenergyservices.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-blue-100 p-3 rounded-full text-blue-900"><Phone size={20} /></div>
                <div>
                  <h4 className="font-bold text-gray-900">Call Us</h4>
                  <p className="text-gray-600">+234 803 536 9473</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-slate-50 p-8 rounded-xl border border-gray-200">
             <h3 className="text-xl font-bold mb-6">Send an Inquiry / RFQ</h3>
             <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <input 
                    required
                    placeholder="Full Name" 
                    className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-900 outline-none"
                    value={form.name}
                    onChange={e => setForm({...form, name: e.target.value})}
                   />
                   <input 
                    placeholder="Company Name" 
                    className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-900 outline-none"
                    value={form.company || ''}
                    onChange={e => setForm({...form, company: e.target.value})}
                   />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <input 
                    required type="email"
                    placeholder="Email Address" 
                    className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-900 outline-none"
                    value={form.email}
                    onChange={e => setForm({...form, email: e.target.value})}
                   />
                   <input 
                    required type="tel"
                    placeholder="Phone Number" 
                    className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-900 outline-none"
                    value={form.phone}
                    onChange={e => setForm({...form, phone: e.target.value})}
                   />
                </div>
                <select 
                  className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-900 outline-none"
                  value={form.type}
                  onChange={e => setForm({...form, type: e.target.value})}
                >
                  <option>General Inquiry</option>
                  <option>Request for Quote (RFQ)</option>
                  <option>Partnership</option>
                  <option>Careers</option>
                </select>
                <textarea 
                  required
                  rows={4} 
                  placeholder="How can we help you?" 
                  className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-900 outline-none"
                  value={form.message}
                  onChange={e => setForm({...form, message: e.target.value})}
                ></textarea>
                <Button variant="primary" type="submit" className="w-full" disabled={status === 'submitting'}>
                  {status === 'submitting' ? 'Sending...' : 'Send Message'}
                </Button>
                {status === 'success' && <p className="text-green-600 text-center mt-2">Message sent successfully!</p>}
             </form>
          </div>
        </div>
      </div>
    </section>
  );
};
