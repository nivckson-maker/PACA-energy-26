import React from 'react';
import { Shield } from 'lucide-react';

export const TrustTicker: React.FC = () => (
  <div className="bg-gray-100 border-b border-gray-200 py-6 overflow-hidden">
    <div className="container mx-auto px-4">
      <p className="text-center text-gray-500 text-sm font-semibold uppercase tracking-widest mb-4">Trusted By Industry Leaders</p>
      <div className="flex justify-center flex-wrap gap-8 md:gap-16 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
        {['Greenville LNG', 'Shell', 'ExxonMobil', 'TotalEnergies', 'Daewoo Nigeria'].map((brand, i) => (
          <div key={i} className="text-xl md:text-2xl font-bold text-gray-400 font-serif flex items-center gap-2">
            <Shield size={24} /> {brand}
          </div>
        ))}
      </div>
    </div>
  </div>
);
