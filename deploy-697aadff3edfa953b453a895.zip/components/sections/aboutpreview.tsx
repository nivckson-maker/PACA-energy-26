import React from 'react';
import { Users, Shield } from 'lucide-react';
import { Button } from '../ui/Button.tsx';
import { SectionHeading } from '../ui/SectionHeading.tsx';

interface AboutPreviewProps {
  navigate: (page: string) => void;
}

export const AboutPreview: React.FC<AboutPreviewProps> = ({ navigate }) => (
  <section className="py-20 bg-blue-900 text-white relative overflow-hidden">
    <div className="absolute right-0 top-0 w-1/2 h-full bg-white/5 skew-x-12 pointer-events-none"></div>
    <div className="container mx-auto px-4 relative z-10">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <SectionHeading subtitle="Who We Are" title="Driven by Integrity & Excellence" align="left" light />
          <p className="text-gray-300 mb-6 text-lg leading-relaxed">
            PACA Energy Services Limited is a purely Nigerian company with a mission to be the reference point for true local content development. We combine technical expertise with a proactive QHSE culture to deliver value.
          </p>
          <div className="grid grid-cols-2 gap-6 mb-8">
            <div className="flex flex-col gap-2">
              <h4 className="text-3xl font-bold text-orange-500">100%</h4>
              <p className="text-sm text-gray-400">Indigenous Content</p>
            </div>
            <div className="flex flex-col gap-2">
              <h4 className="text-3xl font-bold text-orange-500">Zero</h4>
              <p className="text-sm text-gray-400">LTI Incidents Goal</p>
            </div>
          </div>
          <Button variant="secondary" onClick={() => navigate('about')}>More About Us</Button>
        </div>
        <div className="grid grid-cols-2 gap-4">
           <div className="bg-white/10 p-6 rounded-lg backdrop-blur-sm border border-white/10">
              <Users className="text-orange-500 mb-4" size={32} />
              <h4 className="font-bold text-lg mb-2">Expert Team</h4>
              <p className="text-sm text-gray-400">Highly skilled engineers and PMP certified managers.</p>
           </div>
           <div className="bg-white/10 p-6 rounded-lg backdrop-blur-sm border border-white/10 mt-8">
              <Shield className="text-orange-500 mb-4" size={32} />
              <h4 className="font-bold text-lg mb-2">QHSE First</h4>
              <p className="text-sm text-gray-400">ISO 9001:2015 aligned quality management systems.</p>
           </div>
        </div>
      </div>
    </div>
  </section>
);
