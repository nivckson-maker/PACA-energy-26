import React from 'react';
import { ChevronRight, Hammer, HardHat, Briefcase, Anchor } from 'lucide-react';
import { Service } from '../../types.ts';
import { SectionHeading } from '../ui/SectionHeading.tsx';

const iconMap: Record<string, any> = {
  Hammer, HardHat, Briefcase, Anchor
};

interface ServicesListProps {
  services: Service[];
}

export const ServicesList: React.FC<ServicesListProps> = ({ services }) => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <SectionHeading subtitle="Our Expertise" title="Core Capabilities" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, idx) => {
            const Icon = iconMap[service.icon] || HardHat;
            return (
              <div key={service.id || idx} className="group p-6 border border-gray-100 rounded-lg hover:shadow-xl transition-all duration-300 bg-white hover:-translate-y-1">
                <div className="w-14 h-14 bg-blue-50 rounded-lg flex items-center justify-center mb-6 group-hover:bg-blue-900 transition-colors">
                  <Icon className="text-blue-900 group-hover:text-white transition-colors" size={28} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed">{service.description}</p>
                <button className="text-orange-600 font-semibold text-sm flex items-center gap-1 group-hover:gap-2 transition-all">
                  Learn More <ChevronRight size={16} />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
