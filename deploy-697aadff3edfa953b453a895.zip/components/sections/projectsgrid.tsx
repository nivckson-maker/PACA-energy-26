import React from 'react';
import { MapPin, HardHat } from 'lucide-react';
import { Project } from '../../types.ts';
import { SectionHeading } from '../ui/SectionHeading.tsx';

interface ProjectsGridProps {
  projects: Project[];
}

export const ProjectsGrid: React.FC<ProjectsGridProps> = ({ projects }) => (
  <section className="py-20 bg-slate-50">
    <div className="container mx-auto px-4">
      <SectionHeading subtitle="Track Record" title="Featured Projects" />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map((project, idx) => (
          <div key={project.id || idx} className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-shadow border border-gray-100">
            <div className="h-48 bg-gray-200 relative group">
               {/* Placeholder for project image since we don't have real URLs */}
               <div className="absolute inset-0 bg-blue-900/10 flex items-center justify-center text-blue-900/20">
                 <HardHat size={48} />
               </div>
               <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-blue-900 shadow-sm">
                 {project.year}
               </div>
            </div>
            <div className="p-6">
              <div className="text-xs font-bold text-orange-600 uppercase tracking-wider mb-2">{project.category}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2">{project.title}</h3>
              <p className="text-sm text-gray-500 mb-4 flex items-center gap-2">
                <MapPin size={14} /> {project.location} • {project.client}
              </p>
              <p className="text-gray-600 text-sm line-clamp-3">{project.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);
