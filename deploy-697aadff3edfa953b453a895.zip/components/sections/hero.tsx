import React from 'react';
import { ArrowRight, CheckCircle } from 'lucide-react';
import { Button } from '../ui/Button.tsx';

interface HeroProps {
  navigate: (page: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ navigate }) => (
  <div className="relative bg-blue-900 h-[600px] flex items-center text-white overflow-hidden">
    <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-20"></div>
    <div className="container mx-auto px-4 relative z-10">
      <div className="max-w-3xl">
        <div className="flex items-center gap-2 mb-4 bg-orange-500/20 w-fit px-3 py-1 rounded-full border border-orange-500/50 backdrop-blur-sm">
          <CheckCircle size={16} className="text-orange-400" />
          <span className="text-sm font-medium text-orange-100">ISO 9001:2015 Aligned</span>
        </div>
        <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6">
          Foremost Indigenous Energy Services Provider
        </h1>
        <p className="text-xl text-gray-200 mb-8 max-w-2xl">
          Delivering world-class construction, maintenance, and project management solutions to the Nigerian Oil & Gas industry with 100% local content compliance.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button variant="secondary" onClick={() => navigate('projects')}>
            View Projects <ArrowRight size={18} />
          </Button>
          <Button variant="outline" className="border-white text-white hover:bg-white/10" onClick={() => navigate('services')}>
            Our Capabilities
          </Button>
        </div>
      </div>
    </div>
  </div>
);
